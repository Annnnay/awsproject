import json
import boto3

def lambda_handler(event, context):
    try:
        
        client_info_list = event['client_info_list']
    except KeyError as e:
       
        error_message = f"Error: {str(e)}"
        return {
            'statusCode': 400,
            'body': json.dumps(error_message)
        }

    batch_size = 10 
    
    # Process client information in batches
    for i in range(0, len(client_info_list), batch_size):
        batch_client_info = client_info_list[i:i+batch_size]
        save_batch_to_rds(batch_client_info)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Client information saved successfully to RDS!')
    }

def save_batch_to_rds(batch_client_info):
    
    db_endpoint = 'rdsdatabase.c1ea0c4kcqvl.us-east-1.rds.amazonaws.com'
    db_username = 'rdsdatabase'
    db_password = 'Zynnx0304'
    db_name = 'rdsdatabase'
    
    # Establish connection to RDS
    rds_client = boto3.client('rds-data')
    
   
    for client_info in batch_client_info:
        sql_query = f"INSERT INTO clients (client_id, name, age) VALUES ('{client_info['client_id']}', '{client_info['name']}', {client_info['age']})"
        try:
            response = rds_client.execute_statement(
                resourceArn='arn:aws:rds:us-east-1:891376955666:cluster:rdsdatabase',
                secretArn='arn:aws:secretsmanager:us-east-1:891376955666:secret:rds-db-credentials/rdsdatabase/rdsdatabase/1711871113021-ZuCJto',
                database='rdsdatabase',
                sql=sql_query
            )
            print(response)
        except Exception as e:
            print(f"Error executing SQL query: {str(e)}")

